from causica.nn.deci_embed_nn import DECIEmbedNN
